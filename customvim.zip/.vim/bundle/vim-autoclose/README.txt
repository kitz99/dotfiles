==========
README.txt
==========

    This  plugin was  born  as a  personal  need to  get  some little  special
features from other editors into my  preferred one. The Eclipse IDE editor has
an  auto-complete for  open-close pair  of  characters feature  that I  always
wanted into Vim.

    As  soon as  you type  a character  that could  have a  matching (closing)
counterpart,  Eclipse automatically  puts  its counterpart  in  front of  your
cursor, and it is smart enough  to ignore the closing character afterwards, if
typed, but just moves your cursor one character forward.

    But  the Eclipse  editor  does not  stop  there. If  you  type an  opening
character on any part of your code  that should not have a pair completion, it
will not insert the closing character for you.

    The AutoClose plugin is an attempt to reproduce this behavior for Vim.

